## General guidelines

The best thing about the MuleSoft community is contributions. If you notice a way to improve this project then send us a pull request.

#### Flow

-   Fork the Project
-   Create your Feature Branch (git checkout -b feature/NewFeature)
-   Commit your Changes (git commit -m 'Add some NewFeature')
-   Push to the Branch (git push origin feature/NewFeature)
-   Open a Pull Request
